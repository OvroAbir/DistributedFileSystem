import client.Client;

public class ClientRun {

	public static void main(String[] args) {
		System.out.println("Starting client");
		Client client = new Client();
	}

}
