package messages;

public class SuccessMessage extends MessageType {

	public SuccessMessage(String messageFrom) {
		super(SUCCESS_MESSAGE, messageFrom);
	}

}
