import control_node.ControlNode;

public class ControlNodeRun {

	public static void main(String[] args) throws InterruptedException 
	{
		System.out.println("Starting Control Node");
		ControlNode controlNode = new ControlNode();
		
	}

}
