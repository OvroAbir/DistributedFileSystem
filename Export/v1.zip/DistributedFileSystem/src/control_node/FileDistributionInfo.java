package control_node;

import java.util.ArrayList;

public class FileDistributionInfo 
{
	private int numberOfChunks;
	private int fileSize; // number of bytes
	
}
